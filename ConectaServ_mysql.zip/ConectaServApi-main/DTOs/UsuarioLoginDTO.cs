﻿namespace ConectaServApi.DTOs
{
    public class UsuarioLoginDTO
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
