﻿namespace ConectaServApi.DTOs
{
    public class UsuarioCadastroDTO
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
