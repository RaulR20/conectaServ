﻿namespace ConectaServApi.DTOs
{
    public class ClienteCadastroDTO
    {
        public string CPF { get; set; }
        public string Telefone { get; set; }
        public string Celular { get; set; }
    }
}
