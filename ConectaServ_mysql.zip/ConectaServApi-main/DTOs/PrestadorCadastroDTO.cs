﻿namespace ConectaServApi.DTOs
{
    public class PrestadorCadastroDTO
    {
        public string Cnpj { get; set; }
        public string NomeFantasia { get; set; }
        public string? RazaoSocial { get; set; }
        public string? Telefone { get; set; }
        public string Celular { get; set; }
        public string? Site { get; set; }
    }
}
